Snapshot of At the Circulating Library: A Database of Victorian Fiction, 1837–1901

Version 0.6

This snapshot was made on 30 May 2018 and consists of three files:

1. authors.csv: Lists all of the authors currently in the database with fields for author_id, first_name, middle_name, last_name, alt_name, birth_year, death_year, and gender.  Please note, the alt_name field is a catch-all field for familiar, legal, and maiden names as well as pseudonyms and titles.

In general, authors are listed under their legal names.  In some cases, however, authors are listed under pseudonyms or titles if those names are better known (e.g., George Eliot).

The codes for gender are female (F), male (M), and unknown (U).

2. titles.csv: Lists all of the titles currently in the database with fields for title_id, author_id, title, volumes, publisher_location, publisher_name, and publication_year.  Please note, the author_id field is keyed to the author_id field in the authors.csv file.

3. readme.txt