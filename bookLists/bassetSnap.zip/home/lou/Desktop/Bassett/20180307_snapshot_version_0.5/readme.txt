Snapshot of At the Circulating Library: A Database of Victorian Fiction, 1837–1901

Version 0.5

This snapshot was made on 7 March 2018 and consists of three files:

1. authors.csv: Lists all of the authors currently in the database with fields for author_id, first_name, middle_name, last_name, alt_name, birth_year, death_year, and gender.  Please note, the alt_name field is a catch-all field for legal, maiden, and pen names.

2. titles.csv: Lists all of the titles currently in the database with fields for title_id, author_id, title, publisher_name, and publication_year.  Please note, the author_id field is keyed to the author_id field in the authors.csv file.

3. readme.txt

I modified these files as follows
a) both csv files hand edited to convert escaped quotes (\") into entity references [titles2.csv,
authors2.csv]
b) both csv files opened in Libre Office calc, exported as xml files
c) authors2.xml file converted to authors.tei (using authors2tei.xsl and titles2tei.xsl)
d) titles2.xml file converted, enriched with magic key, and merged with 
authors.tei to give bassetBibl.xml



